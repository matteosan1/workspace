#ifndef ORING_H
#define ORING_H

int testOring();

#endif
